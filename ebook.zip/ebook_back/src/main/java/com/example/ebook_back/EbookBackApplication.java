package com.example.ebook_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbookBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(EbookBackApplication.class, args);
    }

}
