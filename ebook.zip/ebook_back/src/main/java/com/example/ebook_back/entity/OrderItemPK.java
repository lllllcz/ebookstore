package com.example.ebook_back.entity;

import java.io.Serializable;

public class OrderItemPK implements Serializable {

    private int orderId;

    private Integer bookId;
}